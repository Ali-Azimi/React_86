const Question = ({ title, options = [] }) => {
  return (
    <>
      <h2>{title}</h2>
      <ul className="optionList">
        {options.map((option, index) => (
          <li className="option" key={index}>{option}</li>
        ))}
      </ul>
    </>
  );
};

export default Question;
