import React, { useState } from "react";

const MyForm = () => {
  const [inputValue, setInputValue] = useState("09");
  const [hasError, setHasError] = useState(null);

  const handleChange = (event) => {
    const pattern = /^989[0-9]{9}$/;
    const value = event.target.value;
    setInputValue(value);

    if (pattern.test(value)) {
      setHasError(false);
    } else {
      setHasError(true);
    }
  };

  return (
    <>
      <h3>MyForm</h3>
      <input
        type="text"
        placeholder="phoneNumber"
        value={inputValue}
        onChange={handleChange}
        className={`${hasError === true ? "error" : ""} ${
          hasError === false ? "pass" : ""
        }`}
      />
      <button disabled={hasError}>Submit</button>
    </>
  );
};

export default MyForm;
