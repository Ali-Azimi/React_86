


import React from 'react'

const AboutUs = () => {
  return (
    <h1>AboutUs</h1>
  )
}

export default AboutUs