import React from "react";
import Counter from "./Counter";

const ContactUs = () => {
  return (
    <>
      <h1>ContactUs</h1>
      <Counter />
    </>
  );
};

export default ContactUs;
