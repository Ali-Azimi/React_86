import React from "react";
import Navbar from "./Navbar";

function Layout({children}) {
  return (
    <>
      <Navbar />
        {children}
      <footer>CopyRight Folan</footer>
    </>
  );
}

export default Layout;
