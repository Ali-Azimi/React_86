import React, { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import useFetch from "../hooks/useFetch";

const ProductDetail = () => {
  const {data, isLoading, hasError} = useFetch('https://fakestoreapi.com/products')

  return (
    <>
      <img width={600} src={product.image} />
      <h1>{product?.title}</h1>
      <p>{product.description}</p>
    </>
  );
};

export default ProductDetail;
