import React, { useReducer, useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "./Navbar";
import useHarchi from "../hooks/useHarchi";
import CounterReducer from "../reducers/CounterReducer";


const HomePage = () => {
  const [state, dispatch] = useReducer(CounterReducer, 0)



  
  return (
    <>
      <h1>HomePage</h1>
      <h2>Counter: {state}</h2>
      <button onClick={() => dispatch({type: 'add', payload: 2})}>ADD</button>
      <button onClick={() => dispatch('minus')}>ADD</button>

    </>
  );
};

export default HomePage;
