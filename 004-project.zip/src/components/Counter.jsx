import { useState } from "react";
import useHarchi from "../hooks/useHarchi";

const Counter = () => {

    const {count, handleAdd} = useHarchi()
  return (
    <>
      <h1>Counter: {count}</h1>
      <button onClick={handleAdd}>ADD</button>
    </>
  );
};


export default Counter;