import { useEffect, useState } from "react"



const useFetch = (url) => {
    const [data, setData] = useState([])
    const [isLoading, setIsLoading] = useState(false);
    const [hasError, setHasError] = useState(false);



    useEffect(() => {
        setIsLoading(true)
        fetch(url)
        .then(res => res.json())
        .then(data => setData(data))
        .catch(error => setHasError(error))
        .finally(()=> {
            setIsLoading(false)
        })
    }, [])

    return {data, isLoading, hasError}
}

export default useFetch;