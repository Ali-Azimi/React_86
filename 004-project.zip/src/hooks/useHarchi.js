import { useState } from "react";




const useHarchi = () => {
    const [count, setCount] = useState(0);


    const handleAdd = () => {
        setCount(prev => prev+1)
    }


    return {count, handleAdd}
}


export default useHarchi;