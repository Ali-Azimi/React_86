



const CounterReducer = (state, action) => {
  switch(action.type) {
    case 'add' :
        return state + action.payload

    case 'minus' :
        return state - 1

    default :
        return state
  }
}


export default CounterReducer