import { BrowserRouter, Route, Routes } from "react-router-dom";
import MyForm from "./components/MyForm";
import HomePage from "./components/HomePage";
import AboutUs from "./components/AboutUs";
import ContactUs from "./components/ContactUs";
import Layout from "./components/Layout";
import ProductDetail from "./components/ProductDetail";

const App = () => {
  return (
    <>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route element={<HomePage />} path="/" />
            <Route element={<AboutUs />} path="/about" />
            <Route element={<ContactUs />} path="/contact" />
            <Route element={<ProductDetail />} path="/product/:id" />
            <Route element={<h1>Not Found</h1>} path="*" />
          </Routes>
        </Layout>
      </BrowserRouter>
    </>
  );
};

export default App;
