import React from 'react';

const UserProfile = () => {
  return (
    <div>
      <h3>Your Profile</h3>
      <p>Name: username</p>
      <p>Email: email</p>
    </div>
  );
};

export default UserProfile;
