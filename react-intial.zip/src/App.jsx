import ProductCard from "./components/Card";
import Header from "./components/Header";

function App() {
  return (
    <div>
      <Header />
      <h1>HI MY FIRST COMPONENT</h1>
      <section className="row">
        <ProductCard price={100} title="product 1" freeShipping={true} discount={20} />
        <ProductCard price={200} title="product 2" freeShipping={false} />
        <ProductCard price={350} title="product 3" freeShipping={true} discount={40} />
      </section>
    </div>
  );
}

export default App;
