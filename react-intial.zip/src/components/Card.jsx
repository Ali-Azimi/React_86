


const ProductCard = ({title, price, freeShipping}) => {
    // const title = props.title;
    // const price = props.price;
    // es6 destruction
    // const {title, price} = props;

    return (
        <div className="card">
            {freeShipping && <div className="badge">Free Shipping </div>}
            <img src="images/product.webp" />
            <h3>{title}</h3>
            <p className={price > 200 ? 'red' : ''}>price: {price}$</p>
        </div>
    )
}


export default ProductCard;