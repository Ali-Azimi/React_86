const EndGame = ({score}) => {

  return (
    <>
      <h1>GAME OVER</h1>
      <h2>Your Total Score is : {score} </h2>
    </>
  );
};

export default EndGame;
