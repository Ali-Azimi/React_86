



import React from 'react'

const ProgressStats = ({currentQuestion, totalQuestions, points, totalPoints}) => {
  return (
    <section className="stats">
        <div>
          Question {currentQuestion}/{totalQuestions}
        </div>

        <div>
          Points {points} / {totalPoints}
        </div>
      </section>
  )
}

export default ProgressStats