

import React from 'react'
import styles from './index.module.css';

export const ProgressBar = ({progress}) => {
  return (
    <div className={styles.container}>
        <div className={styles.progress} style={{width: `${progress}%`}}></div>
    </div>
  )
}
