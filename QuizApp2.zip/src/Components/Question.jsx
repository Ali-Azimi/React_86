const Question = ({
  title,
  options = [],
  onAnswer,
  correctOption,
  answred,
}) => {
  const isAnswred = answred !== null;

  const getClassName = (index) => {
    if (!isAnswred) {
      return "";
    }

    if (correctOption === index) {
      return "correct";
    } else {
      return "incorrect";
    }
  };
  return (
    <>
      <h2>{title}</h2>
      <ul className="optionList">
        {options.map((option, index) => {
          return (
            <li
              className={`option ${getClassName(index)}`}
              onClick={() => onAnswer(index)}
              key={index}
            >
              {option}{" "}
              {isAnswred && answred === index && (
                <span className="small">(your answer)</span>
              )}
            </li>
          );
        })}
      </ul>
    </>
  );
};

export default Question;
