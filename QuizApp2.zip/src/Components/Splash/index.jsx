const StartQuiz = ({onStartGame}) => {

  return (
    <>
      <h1>Lets Quiz your Skills</h1>
      <button className="primary" onClick={onStartGame}>Start Game</button>
    </>
  );
};

export default StartQuiz;
