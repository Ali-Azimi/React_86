


import React from 'react'
import Boxes from './Components/Boxes'
import Counter from './Components/Counter'
import Todo from './Components/Todo'
import StopWatch from './Components/StopWatch'
import Products from './Components/Products'

const App = () => {
  return (
    // <Boxes />
    // <Counter />
    // <Todo />
    // <StopWatch />
    <Products />
  )
}

export default App