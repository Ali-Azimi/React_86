import React, { useState } from "react";
import Box from "./Box";

const Boxes = () => {
  

 
  return (
    <section className="grid">
      {[...Array(16).keys()].map((item, index) => {
        return (
            <Box key={index} />
        );
      })}
    </section>
  );
};

export default Boxes;
