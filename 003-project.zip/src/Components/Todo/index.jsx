import { useRef, useState } from "react";

const Todo = () => {
  const [todoList, setTodoList] = useState([
    { title: "running", isDone: false },
  ]);

  const [filteredList, setFilteredList] = useState(todoList);
  const [activeFilter, setActiveFilter] = useState('ALL');

  const inputRef = useRef("");

  const handleClick = () => {
    const value = inputRef.current.value;

    // shallow copy
    // const newState = [...todoList, value];

    // update copy
    // newState.push(value)

    // set state
    // setTodoList(newState);

    const newValue = {
      title: value,
      isDone: false,
    };
    setTodoList((prev) => [...prev, newValue]);
    inputRef.current.value = "";
    inputRef.current.focus();
  };

  const handleDelete = (itemIndex) => {
    const newList = todoList.filter((_item, index) => index !== itemIndex);
    setTodoList(newList);
  };

  const handleDone = (itemIndex) => {
    const newList = todoList.map((item, index) => {
      if (index === itemIndex) {
        return { ...item, isDone: !item.isDone };
      } else {
        return item;
      }
    });
    setTodoList(newList);
  };

  const handleFilter = (isDone, state) => {
    setActiveFilter(state);
    if (isDone === null) {
      setFilteredList(todoList);
    } else {
      const newList = todoList.filter((item) => item.isDone === isDone);
      setFilteredList(newList);
    }
  };


  const showList = activeFilter === 'ALL' ? todoList : filteredList;
  return (
    <>
      <h1>Todo App </h1>
      <input ref={inputRef} type="text" placeholder="write smth..." />
      <button onClick={handleClick}>ADD</button>
      <h3>Work Item List ({showList.length})</h3>
      <div>
        <button
          className={`secondary ${activeFilter === 'ALL' ? "active" : ""}`}
          onClick={() => handleFilter(null, 'ALL')}
        >
          ALL
        </button>
        <button className={`secondary ${activeFilter === 'Done' ? "active" : ""}`} onClick={() => handleFilter(true, 'Done')}>
          Done
        </button>
        <button className={`secondary ${activeFilter === 'UnDone' ? "active" : ""}`} onClick={() => handleFilter(false, 'UnDone')}>
          In Progress
        </button>
      </div>
      <ul>
        {showList.map((todo, i) => (
          <li className={todo.isDone ? "done" : ""} key={i}>
            {todo.title}
            <button onClick={() => handleDelete(i)}>Del</button>
            <button onClick={() => handleDone(i)}>
              {todo.isDone ? "Undone" : "Done"}
            </button>
          </li>
        ))}
      </ul>
    </>
  );
};

export default Todo;
