import React, { useEffect, useRef } from "react";
import { useState } from "react";

const StopWatch = () => {
  const [time, setTime] = useState(0);
  const intervalRef = useRef(null);

  useEffect(() => {
    console.log("EFFECT!!!")
    handlePlay();


    return () => {
        handlePause();
    }
  }, []);

  const handlePlay = () => {
    intervalRef.current = setInterval(() => {
      setTime((prev) => prev + 1);
    }, 1000);
  };

  const handlePause = () => {
    clearInterval(intervalRef.current);
    intervalRef.current = null;
  };
  return (
    <div>
      <h1>StopWatch: {time}</h1>
      <button onClick={handlePlay}>play</button>
      <button onClick={handlePause}>pause</button>
    </div>
  );
};

export default StopWatch;
