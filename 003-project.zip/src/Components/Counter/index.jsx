import { useState } from "react";

const Counter = () => {
    const [state, setState] = useState(0);

    const handleClick = () => {
        // updater function
        setState(state+1)
        setState((prev)=> prev+1)
        setState((prev)=> prev+1)
        setState(state+1)
    }
  return (
    <>
      <h1>Counter: {state}</h1>
      <button onClick={handleClick}>ADD</button>
    </>
  );
};

export default Counter;
