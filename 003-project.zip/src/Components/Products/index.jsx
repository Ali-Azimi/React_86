import React, { useEffect, useState } from "react";
import ProductCard from "../ProductCard";

const Products = () => {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [activeCategory, setActiveCategory] = useState("");
  const [favoriteList, setFavoriteList] = useState([])

  useEffect(() => {
    const controller = new AbortController();
    const baseURL = "https://fakestoreapi.com/products";
    const url = `${baseURL}${
      activeCategory ? `/category/${activeCategory}` : ""
    }`;
    setIsLoading(true);
    fetch(url, { signal: controller.signal })
      .then((response) => response.json())
      .then((data) => {
        setProducts(data);
        setIsLoading(false);
      });

    return () => {
      controller.abort();
    };
  }, [activeCategory]);

  useEffect(() => {
    fetch("https://fakestoreapi.com/products/categories")
      .then((res) => res.json())
      .then((data) => {
        setCategories(data);
      });
  }, []);

  const handleChangeCatgeory = (categoryName) => {
    setActiveCategory(categoryName);
  };

  const handleAddToFaveorite = (product) => {
    setFavoriteList(prev => [...prev, product]);
  }

  return (
    <div>
      <div className="heart">
        <h1>Products {activeCategory}</h1>
        <h3>Favorites ({favoriteList.length})</h3>
      </div>

      <section className="categories">
        {categories.map((item) => (
          <div
            key={item}
            className="category"
            onClick={() => handleChangeCatgeory(item)}
          >
            {item}
          </div>
        ))}
      </section>

      {isLoading ? (
        <h1>Loading...</h1>
      ) : (
        <section className="row">
          {products.map((product) => {
            return <ProductCard key={product.id} {...product} onAddToFavorite={handleAddToFaveorite} />;
          })}
        </section>
      )}
    </div>
  );
};

export default Products;
